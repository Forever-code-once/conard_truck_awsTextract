Wrapper
-------
Demonstrates run-time loading of Server DLL using LoadLibrary and GetProcAddress.


Wrapper Directory Contents
--------------------------
Wrapper\PCMSRV.h   - Type definitions for Server functions. 
Wrapper\PCMSRV.cpp - Example for loading and accessing Server functions.
Wrapper\Test.cpp   - Source file for the calling application (console).

