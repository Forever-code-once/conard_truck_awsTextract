Simptest
--------
Visual Basic example using Server COM interface.  Demonstrates basic
Server COM interface functionality.

Simptest Directory Contents
---------------------------
Project1.vbp - Sample Visual Basic project for using Server COM interface.
Form1.frm    - Sample Visual Basic form for using Server COM interface.
