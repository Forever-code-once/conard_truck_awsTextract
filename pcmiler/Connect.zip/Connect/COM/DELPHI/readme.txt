DELPHI
--------
Delphi example using Server COM interface.  Demonstrates basic
Server COM interface functionality.

DELPHI Directory Contents
---------------------------
Project1.dpr - Sample Delphi project for using Server COM interface.
Unit1.dfm    - Sample Delphi form for using Server COM interface.
