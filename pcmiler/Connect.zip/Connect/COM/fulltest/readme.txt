Fulltest
--------
Visual Basic example using Server COM interface.  Utilizes full
functionality of Server COM interface.

Fulltest Directory Contents
---------------------------
Project1.vbp - Sample Visual Basic project for using Server COM interface.
Form1.frm    - Sample Visual Basic form for using Server COM interface.
