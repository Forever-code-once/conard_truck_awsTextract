NOTE: These files are for Win 32 VB.  Do not use for VB.Net applications.  See the VB.NET documentation
in the PCM Connect manual and the VB.NET folder. 
--
VB
--
Visual Basic examples using Server DLL.  

VB Directory Contents
---------------------
PCMSRV32.TXT - Visual Basic declaration module for Server DLL.
PCMSDE32.MAK - Sample Visual Basic project for using Server DLL.
PCMSDE32.TXT - Sample Visual Basic form for using Server DLL.

