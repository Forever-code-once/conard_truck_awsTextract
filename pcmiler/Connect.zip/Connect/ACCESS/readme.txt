Access
------
Microsoft Access example using Server DLL.  Refer to Server Help for more 
information.

Access Directory Contents
-------------------------
ACCDEM32.MDB - Sample usage of Server from Microsoft Access.

