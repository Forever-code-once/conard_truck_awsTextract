DELPHI
--
Delphi examples using Server DLL.  

DELPHI Directory Contents
---------------------
PCMSTRIP.PAS - Delphi declaration module for Server DLL.
ConnectDemo.DPR - Sample Delphi project for using Server DLL.
PCMSDE32.DFM - Sample Delphi form for using Server DLL.

