Notice for PC*MILER/Connect 16.0 Java Interface:
* Server.jar has been moved to PMW160\App.  Please update 
  CLASSPATH to reflect this change.
